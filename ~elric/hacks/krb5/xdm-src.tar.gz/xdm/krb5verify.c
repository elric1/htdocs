/* $NetBSD$ */

/*-
 * Copyright (c) 2002 The NetBSD Foundation, Inc.
 * All rights reserved.
 *
 * This code is derived from software contributed to The NetBSD Foundation
 * by Roland C. Dowdeswell.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *        This product includes software developed by the NetBSD
 *        Foundation, Inc. and its contributors.
 * 4. Neither the name of The NetBSD Foundation nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE NETBSD FOUNDATION, INC. AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "dm.h"

#include <krb5/krb5.h>

#include <errno.h>

/* XXX XAX elric:  www, global variables for this gunk.
 *	this point, this is simply to allow for destroying
 *      the ticket on session exit.
 */
static	char		ccacheloc[MAXPATHLEN] = "";

static int Krb5StoreCreds(krb5_context, krb5_creds, int, struct verify_info *);

int
fake_prompter(krb5_context c, void *d, const char *b, int n, krb5_prompt p[])
{
	return 0;
}

krb5_error_code
verify_creds(krb5_context context, krb5_principal user, krb5_creds cred)
{
	krb5_error_code ret;
	krb5_principal server;
	krb5_verify_init_creds_opt opts;

	ret = krb5_sname_to_principal(context, NULL, NULL, KRB5_NT_SRV_HST,
	    &server);
	if (ret)
		return ret;

	krb5_verify_init_creds_opt_init(&opts);
	krb5_verify_init_creds_opt_set_ap_req_nofail(&opts, 1);

	ret = krb5_verify_init_creds(context, &cred, server, NULL, NULL, &opts);
	krb5_free_principal(context, server);
	return ret;
}

/*
 * Krb5Verify is designed to be called from Verify in verify.c.
 * It returns 0 if the athentication failed, and 1 if it succeeds.
 * It will also set up a credential cache:
 *	FILE:/tmp/krb5cc_<uid>.:<display>
 */

int
Krb5Verify(struct display *d, struct greet_info *greet,
    struct verify_info *verify)
{
	krb5_get_init_creds_opt opt;
	krb5_error_code ret;
	krb5_principal me;
	krb5_context context;
	krb5_creds cred;
	krb5_realm realm;

	/* we do not allow root logins via krb5 */

	if (!strcmp(greet->name, "root"))
		return 0;

	memset(&cred, 0x0, sizeof(cred));
	ret = krb5_init_context(&context);
	if (ret) {
		LogError("cannot initialize krb5: %s",
		    krb5_get_err_text(context, ret));
		return 0;
	}

	ret = krb5_get_default_realm(context, &realm);
	if (ret) {
		LogError("cannot retrieve default realm: %s",
		    krb5_get_err_text(context, ret));
		return 0;
	}

	ret = krb5_parse_name(context, greet->name, &me);
	if (ret) {
		LogError("principal (%s) does not parse: %s", greet->name,
		    krb5_get_err_text(context, ret));
		krb5_free_context(context);
		return 0;
	}

	krb5_get_init_creds_opt_init(&opt);
	krb5_get_init_creds_opt_set_default_flags(context, "xdm", realm, &opt);

	ret = krb5_get_init_creds_password(context, &cred, me,
	    greet->password, (krb5_prompter_fct)fake_prompter,
	    NULL, 0, NULL, &opt);
	switch (ret) {
	case 0:
		break;
	case KRB5KRB_AP_ERR_BAD_INTEGRITY:
	case KRB5KRB_AP_ERR_MODIFIED:
		LogError("principal (%s) provided bad password: %s",
		    greet->name, krb5_get_err_text(context, ret));
		krb5_free_principal(context, me);
		krb5_free_context(context);
		return 0;
	default:
		LogError("unknown error for (%s) in Krb5Verify: %s",
		    greet->name, krb5_get_err_text(context, ret));
		krb5_free_principal(context, me);
		krb5_free_context(context);
		return 0;
	}

	/* now verify that the user is in fact who they claim to be */
	if (verify_creds(context, me, cred)) {
		LogError("unable to verify credentials for (%s)", greet->name);
		krb5_free_principal(context, me);
		krb5_free_context(context);
		return 0;
	}

	/* XXX elric : store the ccache, here.
	 *    we ignore errors, since failing to store the cache
	 *    does not invalidate the user.
	 */

	if (Krb5StoreCreds(context, cred, d->displayNumber, verify))
		LogError("cannot store credentials (%s): %s", ccacheloc);

	krb5_free_creds_contents(context, &cred);
	krb5_free_principal(context, me);
	krb5_free_context(context);

	return 1;
}

static int
Krb5StoreCreds(krb5_context context, krb5_creds cred, int dispNum,
	struct verify_info *v)
{
	krb5_error_code ret;
	krb5_ccache ccache;
	char cpath[MAXPATHLEN - 5];	/* the -5 makes room for the FILE: */
	uid_t uid = v->uid;
	gid_t gid = v->gid;

	snprintf(cpath, sizeof(cpath), "/tmp/krb5cc_%d.:%d", uid, dispNum);
	strcpy(ccacheloc, "FILE:");
	strcat(ccacheloc, cpath);
	ret = krb5_cc_resolve(context, ccacheloc, &ccache);
	if (ret) {
		LogError("cannot resolve ccache (%s): %s", ccacheloc,
		    krb5_get_err_text(context, ret));
		return 1;
	}
	ret = krb5_cc_initialize(context, ccache, cred.client);
	if (ret) {
		LogError("cannot initialize ccache: %s",
		    krb5_get_err_text(context, ret));
		return 1;
	}
	ret = krb5_cc_store_cred(context, ccache, &cred);
	if (ret) {
		LogError("cannot store creds in ccache: %s",
		    krb5_get_err_text(context, ret));
		return 1;
	}
	krb5_cc_close(context, ccache);
	if (chown(cpath, uid, gid) == -1) {
		LogError("chown ccache file (%s): %s", ccacheloc,
		    strerror(errno));
		return 1;
	}
	v->userEnviron = setEnv(v->userEnviron, "KRB5CCNAME", ccacheloc);
	return 0;
}

void
Krb5DestroyCreds(void)
{
	krb5_error_code ret;
	krb5_context context;
	krb5_ccache ccache;
	char *tmp;

	if (!ccacheloc)
		return;

	ret = krb5_init_context(&context);
	if (ret) {
		LogError("cannot initialize krb5: %s",
		    krb5_get_err_text(context, ret));
		goto bail;
	}

	ret = krb5_cc_resolve(context, ccacheloc, &ccache);
	if (ret) {
		LogError("cannot resolve ccache (%s): %s", ccacheloc,
		    krb5_get_err_text(context, ret));
		goto bail;
	}

	ret = krb5_cc_destroy(context, ccache);
	if (ret) {
		LogError("cannot resolve ccache (%s): %s", ccacheloc,
		    krb5_get_err_text(context, ret));
		goto bail;
	}

bail:
	ccacheloc[0] = '\0';
}
