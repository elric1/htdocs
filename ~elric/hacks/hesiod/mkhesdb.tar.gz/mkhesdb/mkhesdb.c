/* $NetBSD$ */

/*-
 * Copyright (c) 2002 The NetBSD Foundation, Inc.
 * All rights reserved.
 *
 * This code is derived from software contributed to The NetBSD Foundation
 * by Roland C. Dowdeswell.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *        This product includes software developed by the NetBSD
 *        Foundation, Inc. and its contributors.
 * 4. Neither the name of The NetBSD Foundation nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE NETBSD FOUNDATION, INC. AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <sys/types.h>

#include <errno.h>
#include <grp.h>
#include <malloc.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void usage(void);
static int hesline_string(FILE *, char *, char *, char *);
static int hesline_num(FILE *, char *, unsigned long, char *, char *);
static int strlcatnum(char *, unsigned long, size_t);

/* Global generation options */
int	gen_passwd = 0;
int	gen_groups = 0;
int	gen_shells = 0;
int	gen_ultrix = 0;

void
usage(void)
{

	fprintf(stderr, "usage: mkhesdb [-Ugps] [-o outfile]\n");
}

int
main(int argc, char **argv)
{
	FILE	*outf;
	extern	char *optarg;
	int	ch;
	char	*outfile = NULL;

	while ((ch = getopt(argc, argv, "Ugo:ps")) != -1)
		switch (ch) {
		case 'U':
			gen_ultrix = 1;
			break;
		case 'g':
			gen_groups = 1;
			break;
		case 'o':
			outfile = strdup(optarg);
			break;
		case 'p':
			gen_passwd = 1;
			break;
		case 's':
			gen_shells = 1;
			break;
		case '?':
		default:
			usage();
		}

	if (outfile) {
		outf = fopen(outfile, "w");
		if (!outf) {
			fprintf(stderr, "Can't open outfile \"%s\", %s\n",
			    outfile, strerror(errno));
			exit(1);
		}
	} else {
		outf = stdout;
	}

	if (gen_passwd)
		generate_passwd(outf);
	if (gen_groups)
		generate_groups(outf);
	if (gen_shells)
		generate_shells(outf);
	exit(0);
}

int
generate_passwd(FILE *f)
{
	struct	passwd *pw;
	struct	group *gr;
	int	i;
	int	num = 0;

	setpwent();
	while ((pw = getpwent()) != NULL) {
		char	line[1024];	/* XXXrcd: fix hardcoded */
		gid_t	grps[1024];	/* heh, way too high */
		int	ngrps = 1024;

		snprintf(line, 1024, "%s:%s:%u:%u:%s:%s:%s",
		    pw->pw_name, "*", (unsigned) pw->pw_uid,
		    (unsigned) pw->pw_gid, pw->pw_gecos, pw->pw_dir,
		    pw->pw_shell);

		hesline_string(f, pw->pw_name, "passwd", line);
		hesline_num(f, "", pw->pw_uid, "uid", line);
		if (gen_ultrix)
			hesline_num(f, "passwd-", num++, "passwd", line);

		strcpy(line, "");
		getgrouplist(pw->pw_name, pw->pw_gid, grps, &ngrps);
		for (i=0; i < ngrps; i++) {
			gr = getgrgid(grps[i]);
			if (!gr) {
				fprintf(stderr, "Can't find group %u\n",
				    grps[i]);
				exit(1);
			}
			if (i)
				strlcat(line, ":", 1024);
			strlcat(line, gr->gr_name, 1024);
			strlcat(line, ":", 1024);
			strlcatnum(line, grps[i], 1024);
		}
		hesline_string(f, pw->pw_name, "grplist", line);
	}
	endpwent();
}

int
generate_groups(FILE *f)
{
	struct	group *gr;
	int	i;
	int	num = 0;

	setgrent();
	while ((gr = getgrent()) != NULL) {
		char	line[1024];	/* XXXrcd: fix hardcoded */

		/* XXXrcd: do something with the members. sigh. */
		snprintf(line, 1024, "%s:*:%d:", gr->gr_name, gr->gr_gid);

		i = 0;
		while (gr->gr_mem[i]) {
			if (i)
				strlcat(line, ",", 1024);
			strlcat(line, gr->gr_mem[i++], 1024);
		}

		hesline_string(f, gr->gr_name, "group", line);
		hesline_num(f, "", gr->gr_gid, "gid", line);
		if (gen_ultrix)
			hesline_num(f, "group-", num++, "group", line);
	}
	endgrent();
}

int
generate_shells(FILE *f)
{
	char	*shell;
	int	num = 0;

	setusershell();
	while ((shell = getusershell()) != NULL) {
		hesline_num(f, "shell-", num++, "shells", shell);
	}
}

static int
hesline_num(FILE *f, char *prefix, unsigned long name, char *db, char *line)
{
	char	num[64];

	if (!prefix)
		prefix = "";
	snprintf(num, 64, "%s%lu", prefix, name);
	hesline_string(f, num, db, line);
}

static int
hesline_string(FILE *f, char *name, char *db, char *line)
{
	char *entry;

	entry = malloc(strlen(name)+strlen(db)+2);
	sprintf(entry, "%s.%s", name, db);
	fprintf(f, "%-20.20s HS TXT\t\"%s\"\n", entry, line);
	free(entry);
}

static int
strlcatnum(char *dst, unsigned long src, size_t size)
{
	char	*num;

	num = malloc(size);
	snprintf(num, size, "%lu", src);
	strlcat(dst, num, size);
	free(num);
}
